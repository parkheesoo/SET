import java.awt.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.imageio.ImageIO;
 
@SuppressWarnings("unused")
public class newmain extends JFrame {
   
   Image img = null;

   JButton btn1 = new JButton("�б���Ȱ����");
   JButton btn2 = new JButton("���/������"); 
   JButton btn3 = new JButton("�α���");
  
    newmain(){
    	setTitle("����ȭ��");
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    	Picture();
    	
    	btn1.addActionListener(new MyActionListener());
        btn2.addActionListener(new MyActionListener());
        btn3.addActionListener(new MyActionListener());

        btn1.setFont(new Font("HY����B", Font.BOLD, 20));
        btn2.setFont(new Font("HY����B", Font.BOLD, 20));
        btn3.setFont(new Font("HY����B", Font.BOLD, 20));
       
        btn1.setPreferredSize(new Dimension(160, 35));
        btn2.setPreferredSize(new Dimension(160, 35));
        btn3.setPreferredSize(new Dimension(160, 35));
        
        btn1.setBorder(BorderFactory.createLineBorder(Color.orange, 5));
        btn2.setBorder(BorderFactory.createLineBorder(Color.orange, 5));
        btn3.setBorder(BorderFactory.createLineBorder(Color.orange, 5));
        
        //btn1.setBackground(new Color(255,187,0));
        btn1.setBackground(Color.white);
        btn2.setBackground(Color.white);
        btn3.setBackground(Color.white);
        
        First();
        second();

        setSize(500,650);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
   public void First (){
	   JPanel p1 = new JPanel();
	   JPanel p2 = new JPanel();
	   JPanel p3 = new JPanel();
	   
	   p1.add(btn1);
	   p2.add(btn2);
	   p3.add(btn3);
	     
	   p1.setBackground(new Color(253, 225, 145));
	   p2.setBackground(new Color(253, 225, 145));
	   p3.setBackground(new Color(253, 225, 145));
	    
	   add(p1);
	   add(p2);
	   add(p3);
	   
	   p1.setBounds(5, 220, 470, 50);
	   p2.setBounds(5, 290, 470, 50);
	   p3.setBounds(5, 360, 470, 50);
	   
   }
   
   public void second() {
	   JPanel p = new JPanel();
       p.setLayout(null);
       
       Label l1= new Label(" ");
       l1.setFont(new Font("HY����B", Font.BOLD, 20));
       
       l1.setBackground(Color.white);
       p.setBackground(Color.white);
       
       add(l1);
       add(p);
       
       l1.setBounds(5, 0, 60, 40);
   }
   
   public void Picture() {
	   JLabel label = new JLabel(new ImageIcon("images/newmainimage.png"));
	   JLabel label2 = new JLabel(new ImageIcon("images/move.gif"));
	   
	   add(label);
	   add(label2);
	   
	   label.setBounds(0, 0, 490, 200);
	   label2.setBounds(5, 420, 490, 300);
   }
   
   class MyActionListener implements ActionListener{
   public void actionPerformed(ActionEvent e) {
	   setVisible(false);
	   Object b = e.getSource();
	   if(b == btn1) {
		   new newmenu();   
	   }
	   else if(b == btn2) {
		   new AD();   
	   }
	   else {
		   new ex1();   
	   }   
   }
 }
 
   public static void main(String[] args) {
      // TODO Auto-generated method stub
        new newmain();
   }
 }