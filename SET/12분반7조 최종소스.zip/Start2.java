import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.imageio.ImageIO;

 
@SuppressWarnings("unused")
public class Start2 extends JFrame {
   
   Image img = null;
   JButton btn1 = new JButton("����ȭ��"); 
   JButton btn2 = new JButton("ó��ȭ��"); 
   
   
 
    Start2(){
       
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   

    
    setTitle("�н�ȭ��");
    setBackground(new Color(254,236,184));
    setSize(800,650);
    
    First();
    second();
    
    setLocationRelativeTo(null);
    setVisible(true);
    
    }
    
   public void First (){
      
    JPanel p1 = new JPanel();  
    JPanel p2 = new JPanel();  
    
    p1.add(btn1);
    p2.add(btn2);

   btn1.setFont(new Font("HY����B", Font.BOLD,25));
   btn2.setFont(new Font("HY����B", Font.BOLD,25));
   
   btn1.setBackground(Color.white);
   btn2.setBackground(Color.white);

     
    add(p1);
    add(p2);

    
    p1.setBounds(0, 560, 200, 50);
    p2.setBounds(586, 560, 200, 50);

    
    p1.setBackground(new Color(254,236,184));
    p2.setBackground(new Color(254,236,184));

    
   }
   
   public void second() {
      JPanel p = new JPanel();
       p.setLayout(null);
       p.setBackground(new Color(254,236,184));
      
      JLabel l1 = new JLabel("��                ȭ                ��                ��                ��"); 
      JLabel l2 = new JLabel("�������Ĵ�");
      JLabel l3 = new JLabel("�л�ȸ�Ĵ�");
      JLabel l4 = new JLabel("����Ĵ�");
      TextArea t1 = new TextArea(); 
      TextArea t2 = new TextArea(); 
      TextArea t3 = new TextArea(); 
      TextArea t4 = new TextArea(); 
      TextArea t5 = new TextArea(); 
      TextArea t6 = new TextArea(); 
      TextArea t7 = new TextArea(); 
      TextArea t8 = new TextArea(); 
      TextArea t9 = new TextArea(); 
      TextArea t10 = new TextArea(); 
      TextArea t11 = new TextArea(); 
      TextArea t12 = new TextArea(); 
      TextArea t13 = new TextArea(); 
      TextArea t14 = new TextArea(); 
      TextArea t15 = new TextArea(); 
      TextArea t16 = new TextArea(); 
      TextArea t17 = new TextArea(); 
      TextArea t18 = new TextArea(); 
      TextArea t19 = new TextArea(); 
      TextArea t20 = new TextArea(); 

      l1.setFont(new Font("HY����B", Font.BOLD, 20));
      l2.setFont(new Font("HY����B", Font.BOLD, 19));
      l3.setFont(new Font("HY����B", Font.BOLD, 19));
      l4.setFont(new Font("HY����B", Font.BOLD, 19));
      //t1.setFont(new Font("�޸ո���T", Font.BOLD,15));
      //t2.setFont(new Font("�޸ո���T", Font.BOLD,15));
         add(t1);
         add(t2);
         add(t3);
         add(t4);
         add(t5);
         add(t6);
         add(t7);
         add(t8);
         add(t9);
         add(t10);
         add(t11);
         add(t12);
         add(t13);
         add(t14);
         add(t15);
         add(t16);
         add(t17);
         add(t18);
         add(t19);
         add(t20);
         add(l1);
         add(l2);
         add(l3);
         add(l4);
         
         t1.setBounds(105, 50, 130, 110);
         t2.setBounds(105, 160, 130, 110);
         t3.setBounds(240, 50, 130, 110);
         t4.setBounds(240, 160, 130, 110);
         t5.setBounds(375, 50, 130, 110);
         t6.setBounds(375, 160, 130, 110);
         t7.setBounds(510, 50, 130, 110);
         t8.setBounds(510, 160, 130, 110);
         t9.setBounds(645, 50, 130, 110);
         t10.setBounds(645, 160, 130, 110);
         t11.setBounds(105, 280, 130, 110);
         t12.setBounds(240, 280, 130, 110);
         t13.setBounds(375, 280, 130, 110);
         t14.setBounds(510, 280, 130, 110);
         t15.setBounds(645, 280, 130, 110);
         t16.setBounds(105, 400, 130, 110);
         t17.setBounds(240, 400, 130, 110);
         t18.setBounds(375, 400, 130, 110);
         t19.setBounds(510, 400, 130, 110);
         t20.setBounds(645, 400, 130, 110);
         l1.setBounds(158, 20, 600, 20);
         l2.setBounds(5, 70, 600, 20);
         l3.setBounds(5, 300, 600, 20);
         l4.setBounds(5, 420, 600, 20);
         //t2.setEditable(false);//���� �Ұ��� �ϰ� ������ִ� ��
       try { 
           String s; 
           String ss;
           BufferedReader br = new BufferedReader(new FileReader("�������Ĵ�2.txt")); 
           while ((s = br.readLine()) != null) { 
              String[] change = s.split("#");

            
             t1.setText(change[1].replaceAll("~", "\r\n"));             
             t2.setText(change[2].replaceAll("~", "\r\n"));
             t3.setText(change[3].replaceAll("~", "\r\n"));
             t4.setText(change[4].replaceAll("~", "\r\n"));
             t5.setText(change[5].replaceAll("~", "\r\n"));
             t6.setText(change[6].replaceAll("~", "\r\n"));
             t7.setText(change[7].replaceAll("~", "\r\n"));
             t8.setText(change[8].replaceAll("~", "\r\n"));
             t9.setText(change[9].replaceAll("~", "\r\n"));
             t10.setText(change[10].replaceAll("~", "\r\n"));
             t11.setText(change[10].replaceAll("~", "\r\n"));
             t12.setText(change[11].replaceAll("~", "\r\n"));
             t13.setText(change[12].replaceAll("~", "\r\n"));
             t14.setText(change[13].replaceAll("~", "\r\n"));
             t15.setText(change[14].replaceAll("~", "\r\n"));
             t16.setText(change[15].replaceAll("~", "\r\n"));
             t17.setText(change[16].replaceAll("~", "\r\n"));
             t18.setText(change[17].replaceAll("~", "\r\n"));
             t19.setText(change[18].replaceAll("~", "\r\n"));
             t20.setText(change[19].replaceAll("~", "\r\n"));
             t1.setFont(new Font("HY����B", Font.BOLD,13));
             t2.setFont(new Font("HY����B", Font.BOLD,13));
             t3.setFont(new Font("HY����B", Font.BOLD,13));
             t4.setFont(new Font("HY����B", Font.BOLD,13));
             t5.setFont(new Font("HY����B", Font.BOLD,13));
             t6.setFont(new Font("HY����B", Font.BOLD,13));
             t7.setFont(new Font("HY����B", Font.BOLD,13));
             t8.setFont(new Font("HY����B", Font.BOLD,13));
             t9.setFont(new Font("HY����B", Font.BOLD,13));
             t10.setFont(new Font("HY����B", Font.BOLD,13));
             t11.setFont(new Font("HY����B", Font.BOLD,13));
             t12.setFont(new Font("HY����B", Font.BOLD,13));
             t13.setFont(new Font("HY����B", Font.BOLD,13));
             t14.setFont(new Font("HY����B", Font.BOLD,13));
             t15.setFont(new Font("HY����B", Font.BOLD,13));
             t16.setFont(new Font("HY����B", Font.BOLD,13));
             t17.setFont(new Font("HY����B", Font.BOLD,13));
             t18.setFont(new Font("HY����B", Font.BOLD,13));
             t19.setFont(new Font("HY����B", Font.BOLD,13));
             t20.setFont(new Font("HY����B", Font.BOLD,13));
           } 
           br.close(); 
           } catch (IOException e2) { 
           e2.printStackTrace(); 
        } 
      add(p);
    
   //}
   
   btn1.addActionListener(new ActionListener() {
       @Override
       public void actionPerformed(ActionEvent e) {
          setVisible(false);
          new newmenu();   
       }   
    });
   
   btn2.addActionListener(new ActionListener() {
       @Override
       public void actionPerformed(ActionEvent e) {
          setVisible(false);
          new newmain();   
       }   
    });
   
   }
   public static void main(String[] args) {
      // TODO Auto-generated method stub
        new Start2();
   }
 }