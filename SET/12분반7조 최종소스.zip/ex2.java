import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class ex2 extends JFrame {//ȸ������ȭ��
   public ex2(){
           JPanel p = new JPanel();
           
         JLabel label = new JLabel(new ImageIcon("images/beauty1.jpg"));
         add(label);
         
           JLabel l1= new JLabel("�̸�");   
           JLabel l2 = new JLabel("���̵�");
           JLabel l3= new JLabel("�н�����");
           JLabel l4 = new JLabel("�б�");
           JLabel l5 = new JLabel("�а�");
           l1.setFont(new Font("HY����B", Font.BOLD,18));
           l2.setFont(new Font("HY����B", Font.BOLD,18));
           l3.setFont(new Font("HY����B", Font.BOLD,18));
           l4.setFont(new Font("HY����B", Font.BOLD,18));
           l5.setFont(new Font("HY����B", Font.BOLD,18));
           add(l1);
           add(l2);
           add(l3);
           add(l4);
           add(l5);
           
           TextField t1 = new TextField();
           TextField t2 = new TextField();
           TextField t3 = new TextField();
           TextField t4 = new TextField();
           TextField t5 = new TextField();
           t1.setFont(new Font("HY����B", Font.PLAIN,17));
           t2.setFont(new Font("HY����B", Font.PLAIN,17));
           t3.setFont(new Font("HY����B", Font.PLAIN,17));
           t4.setFont(new Font("HY����B", Font.PLAIN,17));
           t5.setFont(new Font("HY����B", Font.PLAIN,17));
           add(t1);
           add(t2);
           add(t3);
           add(t4);
           add(t5);
           t3.setEchoChar('*');
           
           label.setBounds(0, 0, 500, 100);
           label.setBorder(BorderFactory.createLineBorder(Color.white, 5));
          
           l1.setBounds(40, 140, 60, 40);
           l2.setBounds(40, 190, 60, 40);
           l3.setBounds(40, 240,80,40);
           l4.setBounds(40, 290, 60, 40);
           l5.setBounds(40, 340, 80, 40);
          
           t1.setBounds(150, 140, 200, 30);
           t2.setBounds(150, 190, 200, 30);
           t3.setBounds(150, 240, 200, 30);
           t4.setBounds(150, 290, 280, 30);
           t5.setBounds(150, 340, 280, 30);
          
           JPanel p2 = new JPanel();
           p2.setLayout(new FlowLayout());
           
           JPanel p3 = new JPanel();
           p3.setLayout(new GridLayout(2,2,10,10));
           
           JButton j1 = new JButton("����"); 
           JButton j2 = new JButton("�ڷΰ���");
           JLabel nothing = new JLabel("");
            
           j1.setFont(new Font("�޸ո���T", Font.BOLD,15));
           j2.setFont(new Font("�޸ո���T", Font.BOLD,15));
           
           j1.setPreferredSize(new Dimension(100, 35));
           j2.setPreferredSize(new Dimension(100, 35));
           //j1.setBorder(BorderFactory.createLineBorder(Color.orange, 5));
           
           p3.add(j1);
           p3.add(j2);
           p3.add(nothing);
           p3.add(nothing);
           
           
           p2.add(p3);
           j1.setBackground(Color.white);
           j2.setBackground(Color.white);
           
           p.setBackground(new Color(253, 225, 145));
           p2.setBackground(new Color(253, 225, 145));
           p3.setBackground(new Color(253, 225, 145));
           
       add(p);
       add(p2, BorderLayout.SOUTH);
      setSize(500,550);
      setTitle("ȸ������");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
       setVisible(true);
       j1.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent T) {//ȸ������ ������ ����
         try{
            BufferedWriter bos = new BufferedWriter(new FileWriter("ȸ������.txt",true));
            bos.write(t1.getText()+"/");
            bos.write(t2.getText()+"/");
            bos.write(t3.getText()+"/");
            bos.write(t4.getText()+"/");
            bos.write(t5.getText()+"\r\n");
            bos.close();
            JOptionPane.showMessageDialog(null, "ȸ�������� �����մϴ�!!");
            new ex1();
            dispose();
         }catch (Exception ex){
            JOptionPane.showMessageDialog(null, "ȸ�����Կ� �����Ͽ����ϴ�.");
         }
      }
   });
       j2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent T) {
             setVisible(false);
          new  ex1();
          }
       });
   }
    class MyActionListener implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            JButton b = (JButton)e.getSource();
            new ex1();
         }
      }
}
