import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;
import javax.swing.table.*;

import jxl.*;
import jxl.write.*;

public class term211{
   
    void fillData(JTable table, File file) {

        try {

            WritableWorkbook Workbook1 = Workbook.createWorkbook(file);
            WritableSheet Sheet1 = Workbook1.createSheet("First Sheet", 0); 
            TableModel model = table.getModel();

            for (int i = 0; i < model.getColumnCount(); i++) {
                Label column = new Label(i, 0, model.getColumnName(i));
                Sheet1.addCell(column);
            }
            int j = 0;
            for (int i = 0; i < model.getRowCount(); i++) {
                for (j = 0; j < model.getColumnCount(); j++) {
                    Label row = new Label(j, i + 1, 
                            model.getValueAt(i, j).toString());
                    Sheet1.addCell(row);
                }
            }
            Workbook1.write();
            Workbook1.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    term211(){
       String[][] Time = {{"9:00 ~ 9:50", "", "", "", "", ""},
                {"10:00 ~ 10:50", "", "", "", "", ""},
                {"11:00 ~ 11:50", "", "", "", "", ""},
                {"12:00 ~ 12:50", "", "", "", "", ""},
                {"1:00 ~ 1:50", "", "", "", "", ""},
                {"2:00 ~ 2:50", "", "", "", "", ""},
                {"3:00 ~ 3:50", "", "", "", "", ""},
                {"4:00 ~ 4:50", "", "", "", "", ""},
                {"5:00 ~ 5:50", "", "", "", "", ""}};
            String[] Days = {"�ð�", "������", "ȭ����", "������", "�����", "�ݿ���"};

            JFrame frame = new JFrame("�ð�ǥ���");
            DefaultTableModel model = new DefaultTableModel(Time, Days);
            final JTable table = new JTable(model);
            JScrollPane scroll = new JScrollPane(table);

            JButton Save = new JButton("�����ϱ�");
            JButton Prev = new JButton("�ڷΰ���");
            
            Save.setFont(new Font("HY����B", Font.PLAIN, 17));
            Save.setBackground(Color.orange);
            Save.setBorder(BorderFactory.createLineBorder(Color.white, 1));
            Save.setPreferredSize(new Dimension(160, 30));
            
            Prev.setFont(new Font("HY����B", Font.PLAIN, 17));
            Prev.setBackground(Color.orange);
            Prev.setBorder(BorderFactory.createLineBorder(Color.white, 1));
            Prev.setPreferredSize(new Dimension(160, 30));
            
            Save.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {

                    try {
                        //term211 exp = new term211();
                       fillData(table, new File("C:\\Temp\\data1.xls"));
                        //exp.setVisible(false);
                        
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    frame.setVisible(false);
                    new term21111();
                    //frame.dispose();
                }
            });
            
            Prev.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent evt) {
                frame.setVisible(false);
                  new Start();
                  
                }
            });
            
            JPanel mix = new JPanel();
            mix.setLayout(new GridLayout(1,2));
            mix.add(Save);
            mix.add(Prev);
            
            
            frame.getContentPane().add("Center", scroll);
            frame.getContentPane().add("South", mix);
            frame.pack();
            frame.setVisible(true);
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    protected void setVisible(boolean b) {
      // TODO Auto-generated method stub
      
   }
   public static void main(String[] args) {
       new term211();
    }
}