import javax.swing.table.AbstractTableModel;

public class CalendarTableModel extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	
	private String[] columnNames = {"��", "��", "ȭ", "��", "��", "��", "��"};
	private Object[][] data = null;
	
	public CalendarTableModel(Object[][] data) {
		this.data = data;
	}

	public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		if (data != null) {
			return data.length;
		} else {
			return 0;
		}
	}
	
	public Object getValueAt(int rowIndex, int columnIndex) {
		if(data != null) {
			return data[rowIndex][columnIndex];
		} else {
			return null;
		}
	}
	
	public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }
	
}
