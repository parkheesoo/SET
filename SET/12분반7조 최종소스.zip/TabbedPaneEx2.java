import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

@SuppressWarnings("unused")
class TabbedPaneEx2 extends JFrame {
   public Object btn1;
   public Object btn2;

public TabbedPaneEx2() {
      setTitle("�߰��ϱ����� �ȳ�");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Container c3 = getContentPane();
      JTabbedPane pane = createTabbedPane();
      c3.add(pane, BorderLayout.CENTER);
      
      c3.add(new button(), BorderLayout.SOUTH);
      
      setSize(840,600);
      setLocationRelativeTo(null);
      setVisible(true);
      
   }
   class button extends JPanel {
	   public button(){
		   JButton btn1 = new JButton("�ڷΰ���");
	       JButton btn2 = new JButton("��������");
	      
	       btn1.addActionListener(new MyActionListener());
	       btn2.addActionListener(new MyActionListener());
	       
	       
	       btn1.setFont(new Font("HY����B", Font.BOLD, 17));
	       btn2.setFont(new Font("HY����B", Font.BOLD, 17));
	       
	       
	       btn1.setPreferredSize(new Dimension(130, 30));
	       btn2.setPreferredSize(new Dimension(130, 30));
	       
	       
	       btn1.setBackground(Color.white);
	       btn2.setBackground(Color.white);
	       
	       
	       btn1.setBorder(BorderFactory.createLineBorder(Color.white, 1));
	       btn2.setBorder(BorderFactory.createLineBorder(Color.white, 1));
	       
	       
	       add(btn1);
	       add(btn2);
	       
	   }
	 }

   private JTabbedPane createTabbedPane() {
      JTabbedPane pane = new JTabbedPane();
      setVisible(false);
      pane.addTab("ȿ��,���ε� �߰��ϱ�", new JLabel(new ImageIcon("images/�߰��ϱ�����1.png")));
      pane.addTab("�͹̳� �߰��ϱ�", new JLabel(new ImageIcon("images/�߰��ϱ�����2.png")));
     
      return pane;
   }
   class MyActionListener implements ActionListener {
	   public void actionPerformed(ActionEvent e) {
		   setVisible(false);
		   Object b = e.getSource();
		   if(b == btn1) {
		         new TabbedPaneEx1();
		         }
		         else {
		             new TabbedPaneEx3();
		             }
	   }
   }
   
}