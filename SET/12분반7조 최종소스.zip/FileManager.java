import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileManager {

	public final String FILE_PATH = "C:\\Scheduler\\";

	private BufferedReader br = null;
	private BufferedWriter bw = null;
	private String schedule = "";
	private File file = new File(FILE_PATH);

	public String fileLoad(String fileName) {
		try {
			if (!file.exists()) {
				return "�������� �ʽ��ϴ�...";
			}
			br = new BufferedReader(new FileReader(FILE_PATH + fileName
					+ ".txt"));
			String data = null;
			schedule = "";
			while ((data = br.readLine()) != null) {
				schedule += data + "\n";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return schedule;
	}

	public boolean fileSave(String fileName, String text) {
		try {
			if (!file.exists()) {
				file.mkdir();
			}
			bw = new BufferedWriter(new FileWriter(FILE_PATH + fileName
					+ ".txt"));
			bw.write(text);
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
					// stack�� �ż��尡 ȣ��� ����� ����� �Ǵµ� �̸� StackTrace�̶��ϰ�
					//�� �޼ҵ�� ������ �߻��� �޼ҵ��� ȣ������ ������ش�.
				}
			}
		}
		return true;
	}

	public boolean isSchedule(String filename) {
		String[] list = file.list();
		if (list != null) {
			for (int i = 0; i < list.length; i++) {
				if ((list[i].substring(0, list[i].lastIndexOf(".")))
						.equals(filename)) {
					return true;
				}
			}
		}
		return false;
	}
}
