import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.imageio.ImageIO;

@SuppressWarnings("unused")
public class newmenu extends JFrame{
   
   JButton btn1,btn2,btn3;
   
   newmenu(){
      setTitle("�б���Ȱ����");
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       Container c = getContentPane();
       c.setLayout(new BorderLayout());
       
       ImageIcon haksik = new ImageIcon("images/spoon.png");
       ImageIcon calendar = new ImageIcon("images/calendar.png");
       ImageIcon bus = new ImageIcon("images/bus.png");
       
       JButton btn1 = new JButton("  �н�", haksik); 
       JButton btn2 = new JButton("  �б�����", calendar); 
       JButton btn3 = new JButton("  ��Ʋ����", bus);
       JButton btn4 = new JButton("�ڷΰ���");
       
       JPanel p1 = new JPanel();
       p1.setLayout(new GridLayout(3,1));
       p1.add(btn1);
       p1.add(btn2);
       p1.add(btn3);
       JPanel p4 = new JPanel();
       p4.add(btn4);
       
       p4.setBackground(new Color(253,221,131));
       btn4.setHorizontalAlignment(SwingConstants.CENTER);
       
       btn1.setFont(new Font("HY����B", Font.BOLD, 20));
       btn2.setFont(new Font("HY����B", Font.BOLD, 20));
       btn3.setFont(new Font("HY����B", Font.BOLD, 20));
       btn4.setFont(new Font("HY����B", Font.BOLD, 20));
       //btn4.setMargin(new Insets(0, 0, 0, 0));
       
       btn4.setPreferredSize(new Dimension(160, 35));
       
       btn1.setBackground(new Color(254,236,184));
       btn2.setBackground(new Color(253, 225, 145));
       btn3.setBackground(new Color(254,236,184));
       btn4.setBackground(Color.white);
       
       btn1.setBorder(BorderFactory.createLineBorder(new Color(253,221,131), 1));
       btn2.setBorder(BorderFactory.createLineBorder(new Color(253,221,131), 1));
       btn3.setBorder(BorderFactory.createLineBorder(new Color(253,221,131), 1));
       btn4.setBorder(BorderFactory.createLineBorder(Color.white, 1));
       
       btn1.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
             setVisible(false);
             new Start2();   
          }   
       });
       btn2.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
             setVisible(false);
             new Scheduler();   
          }   
       });
       btn3.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
             setVisible(false);
             new TabbedPaneEx1();   
          }   
       });
       btn4.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
             setVisible(false);
             new newmain();   
          }   
       });
        
       c.add(p1, BorderLayout.CENTER);
       //c.add(p2);
       //c.add(p3);
       c.add(p4, BorderLayout.SOUTH);
       
       setSize(500,600);
       setVisible(true);
       setLocationRelativeTo(null);
   }
   
   public static void main(String[] args) {
      // TODO Auto-generated method stub
      new newmenu();
   }
}