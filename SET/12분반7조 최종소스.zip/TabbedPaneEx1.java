import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

@SuppressWarnings("unused")
class TabbedPaneEx1 extends JFrame {
   public Object btn1;
public Object btn2;

public TabbedPaneEx1() {
      setTitle("���ϱ����� �ȳ�");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Container c2 = getContentPane();
      JTabbedPane pane = createTabbedPane();
      c2.add(pane, BorderLayout.CENTER);
    
      c2.add(new button(), BorderLayout.SOUTH);
      c2.setBackground(Color.white);
      setSize(840,600);
      setLocationRelativeTo(null);
      setVisible(true);
      
   }
   class button extends JPanel{
	   public button() {
		   JButton btn1 = new JButton("�ڷΰ���");
	       JButton btn2 = new JButton("��������"); 
       
       btn1.addActionListener(new MyActionListener());
       btn2.addActionListener(new MyActionListener());
      
       
       btn1.setFont(new Font("HY����B", Font.BOLD, 17));
       btn2.setFont(new Font("HY����B", Font.BOLD, 17));
  
       
       btn1.setPreferredSize(new Dimension(130, 30));
       btn2.setPreferredSize(new Dimension(130, 30));
    
       
       btn1.setBackground(Color.white);
       btn2.setBackground(Color.white);
      
       
       btn1.setBorder(BorderFactory.createLineBorder(Color.white, 1));
       btn2.setBorder(BorderFactory.createLineBorder(Color.white, 1));
    
       
       add(btn1);
       add(btn2);

   }
  }

   private JTabbedPane createTabbedPane() {
      JTabbedPane pane = new JTabbedPane();
      setVisible(false);
      pane.addTab("1ȣ�� ���ϱ�", new JLabel(new ImageIcon("images/1ȣ�� ���ϱ�.png")));
      pane.addTab("2ȣ�� ���ϱ�", new JLabel(new ImageIcon("images/2ȣ�� ���ϱ�.png")));
      pane.addTab("3ȣ�� ���ϱ�", new JLabel(new ImageIcon("images/3ȣ�� ���ϱ�.png")));
      pane.addTab("4ȣ�� ���ϱ�", new JLabel(new ImageIcon("images/4ȣ�� ���ϱ�.png")));
      pane.addTab("5ȣ�� ���ϱ�", new JLabel(new ImageIcon("images/5ȣ�� ���ϱ�.png")));
      pane.addTab("6ȣ�� �", new JLabel(new ImageIcon("images/6ȣ�� �.png")));
      pane.addTab("7ȣ�� �", new JLabel(new ImageIcon("images/7ȣ�� �.png")));
      
      return pane;
      
   }
   class MyActionListener implements ActionListener {
	   public void actionPerformed(ActionEvent e) {
		   setVisible(false);
		   Object b = e.getSource();
		   if(b == btn1) {
		         new newmenu();
		         }
		         else {
		             new TabbedPaneEx2();
		             }
	         
	   }
   }
}