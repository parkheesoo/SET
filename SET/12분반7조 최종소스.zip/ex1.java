import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;

@SuppressWarnings("serial")
public class ex1 extends JFrame{//�α���ȭ��
   Image img = null;
   public ex1()
   {
      JPanel p = new JPanel();
        p.setLayout(null);
        p.setBackground(new Color(253, 225, 145));
        
        JLabel label = new JLabel(new ImageIcon("images/password.png"));
      add(label);
      
      JLabel b2= new JLabel("���̵�");
      b2.setFont(new Font("HY����B", Font.BOLD, 18));
      b2.setBackground(new Color(253, 225, 145));
      add(b2);
      
      JLabel b3= new JLabel("��й�ȣ");
      b3.setFont(new Font("HY����B", Font.BOLD, 18));
      b3.setBackground(new Color(253, 225, 145));
      add(b3);
      
      TextField b4 = new TextField();
      add(b4);
      
      TextField b5 = new TextField();
      add(b5);
      b5.setEchoChar('*');//��ȣȭ
      
      JButton b6 = new JButton("Log-in");
      b6.setFont(new Font("HY����B", Font.BOLD, 15));
      b6.setBackground(Color.white);
      //b6.setBorder(BorderFactory.createLineBorder(Color.white, 1));
      add(b6);
      
      JButton b7 = new JButton("ȸ������");
      b7.setFont(new Font("HY����B", Font.BOLD, 15));
      b7.setBackground(Color.white);
      //b7.setBorder(BorderFactory.createLineBorder(Color.white, 1));
      add(b7);
        
      JButton reset = new JButton("�ڷΰ���");
        reset.setFont(new Font("HY����B", Font.BOLD, 15));
        reset.setBackground(Color.white);
        reset.setBorder(BorderFactory.createLineBorder(Color.white, 1));
        reset.addActionListener(new MyActionListener());
        add(reset);
       
      label.setBounds(0, 10, 480, 255);
      b2.setBounds(40, 265, 70, 40);
      b3.setBounds(40, 305, 80, 40);
      b4.setBounds(150, 265, 200, 30);
      b5.setBounds(150, 305, 200, 30);
      b6.setBounds(370, 265, 100, 30);
      b7.setBounds(370, 305, 100, 30);
      reset.setBounds(200, 400, 100,30);
      add(p);
      
      setSize(500, 550);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setTitle("�α��� ȭ�� ");
      setLocationRelativeTo(null);
      setVisible(true);
      b7.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {//ȸ������â���� �̵�
            // TODO Auto-generated method stub
            setVisible(false);
            ex2 f2= new ex2();
         }
      });;
      b6.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e2) {//�α��� �Ҷ� 
            // TODO Auto-generated method stub
            try{
               String s;
               String[] array;
               BufferedReader bos = new BufferedReader(new FileReader("ȸ������.txt"));
               while((s=bos.readLine())!=null){
                  array=s.split("/");
               if(b4.getText().equals(array[1])&&b5.getText().equals(array[2]))
               {
                  JOptionPane.showMessageDialog(null, "�α����� �Ǿ����ϴ�!!");
                  dispose();
                  new Start();
               }
               else 
               {
                  //JOptionPane.showMessageDialog(null, "�α����� �����Ͽ����ϴ�.");
               	}
               }
               bos.close();
               dispose();
            }catch (IOException E10){
               E10.printStackTrace();
            }
         }
      });
   }
    class MyActionListener implements ActionListener {
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            JButton b = (JButton)e.getSource();
            new newmain();
         }
      }
}