import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

@SuppressWarnings("unused")
class TabbedPaneEx3 extends JFrame {
   public Object btn1;
public Object btn2;

public TabbedPaneEx3() {
      setTitle("��ȯ���� �ȳ�");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Container c4 = getContentPane();
      JTabbedPane pane = createTabbedPane();
      c4.add(pane, BorderLayout.CENTER);
      
      c4.add(new button(), BorderLayout.SOUTH);
      
      setSize(840,600);
      setLocationRelativeTo(null);
      setVisible(true);
      
   }
class button extends JPanel {
	  public button(){
		  JButton btn1 = new JButton("�ڷΰ���");		  
	      JButton btn2 = new JButton("��������");   
	      
	       btn1.addActionListener(new MyActionListener());
	       btn2.addActionListener(new MyActionListener());
	       
	       btn1.setFont(new Font("HY����B", Font.BOLD, 17));
	       btn2.setFont(new Font("HY����B", Font.BOLD, 17));
	       
	       btn1.setPreferredSize(new Dimension(130, 30));
	       btn2.setPreferredSize(new Dimension(130, 30));
	       
	       btn1.setBackground(Color.white);
	       btn2.setBackground(Color.white);
	       
	       btn1.setBorder(BorderFactory.createLineBorder(Color.white, 1));
	       btn2.setBorder(BorderFactory.createLineBorder(Color.white, 1));
	       
	       add(btn1);
	       add(btn2);
	  }
	}

   private JTabbedPane createTabbedPane() {
      JTabbedPane pane = new JTabbedPane();
      setVisible(false);
      pane.addTab("�л굿 ��ȯ1ȣ����", new JLabel(new ImageIcon("images/��ȯ����1.png")));
      pane.addTab("������ ��ȯ2ȣ����", new JLabel(new ImageIcon("images/��ȯ����2.png")));
      pane.addTab("�͹̳� ��ȯ3ȣ����", new JLabel(new ImageIcon("images/��ȯ����3.png")));
      pane.addTab("���Ͽ� ��ȯ4ȣ����", new JLabel(new ImageIcon("images/��ȯ����4.png")));
      pane.addTab("�泲�� ��ȯ5ȣ����", new JLabel(new ImageIcon("images/��ȯ����5.png")));
      pane.addTab("������ ��ȯ����", new JLabel(new ImageIcon("images/��ȯ����6.png")));
      
      return pane;
   }
   class MyActionListener implements ActionListener {
	   public void actionPerformed(ActionEvent e) {
		   setVisible(false);
		   Object b = e.getSource();
		   if(b == btn1) {
		         new TabbedPaneEx2();
		         }
		         else {
		             new newmenu();
		             }
	   }
   }
}