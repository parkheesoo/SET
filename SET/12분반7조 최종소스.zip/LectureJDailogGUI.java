import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class LectureJDailogGUI extends JDialog implements ActionListener{
	
  JPanel pw=new JPanel(new GridLayout(7,1));
  JPanel pc=new JPanel(new GridLayout(7,1));
  JPanel ps=new JPanel();

  JLabel lable_dept = new JLabel("�а�");
  JLabel lable_name=new JLabel("�����");
  JLabel lable_professor=new JLabel("������");
  JLabel lable_book=new JLabel("�����");
  JLabel lable_hakjum=new JLabel("����");
  JLabel lable_esu=new JLabel("�̼�����");
  JLabel lable_infor=new JLabel("��������");


  JTextField dept=new JTextField();
  JTextField name=new JTextField();
  JTextField professor=new JTextField();
  JTextField book=new JTextField();
  JTextField hakjum=new JTextField(); 
  JTextField esu = new JTextField();

  JTextArea infor = new JTextArea();
  JScrollPane scrollpane = new JScrollPane(infor);

  
  JButton reset=new JButton("���");

 MenuJTabaleExam me;
 
  public LectureJDailogGUI(MenuJTabaleExam me, String index){
      super(me,"���̾�α�");
      this.me=me;
      int row = me.jt.getSelectedRow();//���õ� ��
      dept.setText( me.jt.getValueAt(row, 0).toString() );
      name.setText( me.jt.getValueAt(row, 1).toString() );
      professor.setText( me.jt.getValueAt(row, 2).toString() );
      book.setText( me.jt.getValueAt(row, 3).toString() );
      hakjum.setText( me.jt.getValueAt(row, 4).toString() );
      esu.setText( me.jt.getValueAt(row, 5).toString() );
      infor.setText( me.jt.getValueAt(row, 6).toString() );
         
     
         
      //Label�߰��κ�
      pw.add(lable_dept);//ID
      pw.add(lable_name);//�̸�
      pw.add(lable_professor);//����
      pw.add(lable_book);//����
      pw.add(lable_hakjum);//����
      pw.add(lable_esu);//�̼�����
      pw.add(lable_infor);//��������
      pw.setBackground(new Color(253, 225, 145));
      
      dept.setFont(new Font("HY����B", Font.PLAIN, 13));
      name.setFont(new Font("HY����B", Font.PLAIN, 13));
      professor.setFont(new Font("HY����B", Font.PLAIN, 13));
      book.setFont(new Font("HY����B", Font.PLAIN, 13));
      hakjum.setFont(new Font("HY����B", Font.PLAIN, 13));
      esu.setFont(new Font("HY����B", Font.PLAIN, 13));
      infor.setFont(new Font("HY����B", Font.PLAIN, 13));
      reset.setFont(new Font("HY����B", Font.PLAIN, 13));
 
 
 
      //TextField �߰�
      pc.add(dept);
      pc.add(name);
      pc.add(professor);
      pc.add(book);
      pc.add(hakjum);
      pc.add(esu);
      pc.add(scrollpane);
      pc.setBackground(Color.WHITE);
            
      ps.add(reset);
      ps.setBackground(Color.WHITE);
      
      add(pw,"West");
      add(pc,"Center");
      add(ps,"South");
     
      setSize(500,600);
      setVisible(true);
      setLocationRelativeTo(null);

      setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
     
      //�̺�Ʈ���
      reset.addActionListener(this); //��� �̺�Ʈ���
     
  }
 
  @Override
  public void actionPerformed(ActionEvent e) {
     String btnLabel =e.getActionCommand();//�̺�Ʈ��ü ���� Label ��������
     
     if(btnLabel.equals("���")){
         dispose();
         
     }
     
  }
 
  //�޽����ڽ� ����ִ� �޼ҵ� �ۼ�
  public static void messageBox(Object obj , String message){
      JOptionPane.showMessageDialog( (Component)obj , message);
  }

}