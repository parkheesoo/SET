import java.util.Calendar;

public class CalculateDays {
	private Calendar calendar;
	private int year;
	private int month;
	private int maxDay;
	private int firstDay;
	private int week;

	public CalculateDays() {
		calendar = Calendar.getInstance();
		year = calendar.get(Calendar.YEAR);
		month = calendar.get(Calendar.MONTH);
		maxDay = getMaxDay(year, month);
		firstDay = getFirstDay(year, month);
		week = getWeek(year, month, maxDay);
		showCalendar();
	}

	private int getFirstDay(int year, int month) {
		calendar.set(year, month, 1);
		return calendar.get(Calendar.DAY_OF_WEEK);
	}

	private int getWeek(int year, int month, int maxDay) {
		calendar.set(year, month, maxDay);
		return calendar.get(Calendar.WEEK_OF_MONTH);
	}

	private int getMaxDay(int year, int month) {
		calendar.set(year, month, 1);
		return calendar.getActualMaximum(Calendar.DATE);
	}

	public void setYearMonth(int year, int month) {
		this.year = year;
		this.month = month;
		maxDay = getMaxDay(year, month);
		firstDay = getFirstDay(year, month);
		week = getWeek(year, month, maxDay);
	}

	public String[] showCalendar() {
		int dayNum = 1;
		String[] result = new String[week*7];
		for (int i = 0; i < week * 7; i++) {
			if ((i < firstDay - 1) || dayNum > maxDay) {
				result[i] = "  ";
			} else {
				result[i] = Integer.toString(dayNum);
				dayNum++;
			}
		}
		return result;
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}

	public int getWeek() {
		return week;
	}

	public int getMaxDay() {
		return maxDay;
	}

}
