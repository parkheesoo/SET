import java.awt.Label;
import java.awt.TextField;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;



@SuppressWarnings({ "unused", "serial" })
public class HaksikFile2 extends JFrame{

   
   public static void main(String[] args) throws Exception {      
      while(true){
         String target = "http://www.mokwon.ac.kr/sub040401";
         HttpURLConnection con = (HttpURLConnection) new  URL(target).openConnection();
         BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
         FileWriter fw = null; //���� ����� �Լ�
         String temp;
         StringBuffer info = new StringBuffer();
          
         while((temp = br.readLine()) != null) {
           if(temp.contains("<li>��ð� ")) 
           {
               fw = new FileWriter(temp = "�������Ĵ�2.txt");
               fw.write(info.toString());
               fw.close();
            }
            if(temp.contains("br /"))
            {    
               String s = temp.replaceAll("<td class=\"left\">", "#");
               String s2 = s.replaceAll("<br />", "");
               String s3 = s2.replaceAll("&lt;", "<");
               String s4 = s3.replaceAll("&gt;", ">");
               String s5 = s4.replaceAll("/", "&");
               String s6 = s5.replaceAll("      ", "");
               String s7 = s6.replaceAll("&amp;", "&");
               info.append(s7+"~");
               //System.out.println(temp.replaceAll("<td class=\"left\">", ""));
            } 
            if(temp.contains("��ǰ�丮<br />"))
            {
               String a = temp.replaceAll("<td class=\"left\">��ǰ�丮<br />", "");
               String a2 = a.replaceAll("	", "");
               info.append(a2); 
            }
            if(temp.contains("����<br />"))
            {
               String b = temp.replaceAll("<td class=\"left\">����<br />", "");
               String b2 = b.replaceAll("	", "");
               info.append(b2); 
            }
            if(temp.contains("&lt;���츮����&gt;<br />"))
            {
               String c = temp.replaceAll("<td class=\"left\">&lt;���츮����&gt;<br />", "");
               String c2 = c.replaceAll("	", "");
               info.append(c2); 
            }
         }           
         con.disconnect();
         br.close();
         Thread.sleep(1000000000);
         }
   }
   } 