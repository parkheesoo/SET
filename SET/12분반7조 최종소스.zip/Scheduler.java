import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;


@SuppressWarnings("unused")
public class Scheduler extends JFrame {

   private static final long serialVersionUID = 1L;
   //����ȭ�� �ܱⰣ Ȥ�� ��Ⱓ �����͸� �����ϴ� �뵵�� ���� �� �ִµ�,
   //�ܱ� ������ ������ ��Ʈ��ũ�� �����ϴ� ����̰� ��� ������ ������ ���̺� ���ϰ� ���� �뵵�̴�.

   private JPanel contentsPa = null;
   private JPanel inputPa = null;
   private JScrollPane outputPa = null;
   private JTextField yearTF = null;
   private JButton yearUp = null;
   private JButton yearDown = null;
   private JButton backBtn = null;
   private JComboBox monthCb = null;
   private JTable outputTb = null;
   private CalculateDays calendar = null;
   private CalendarTableModel model = null;
   private FileManager fm = null;
   
   private JDialog dialog = null;
   private JPanel dialogCon = null;
   private JScrollPane editerPa = null;
   private JTextArea editer = null;
   private JButton okBt = null;
   private JButton backBt = null;

   private TableColumn column;
   private DefaultTableCellRenderer sunday = null;
   private DefaultTableCellRenderer saturday = null;

   public Scheduler(){
      calendar = new CalculateDays();
      fm = new FileManager();
      makeFrame();
   }
   
   private void makeFrame(){
      this.setSize(500, 450);
      setLocationRelativeTo(null);
      this.setDefaultCloseOperation(EXIT_ON_CLOSE);
      this.setTitle("�б����� �ȳ�");
      this.setVisible(true);
      
      yearTF = new JTextField();
      yearTF.setEditable(false);
      yearTF.setBounds(new Rectangle(120,15,100,30));
      yearTF.setText(Integer.toString(calendar.getYear()));
      
      yearUp = new JButton();
      yearUp.setBounds(new Rectangle(220, 16, 15, 15));
      yearUp.setBackground(Color.white);
      yearUp.addMouseListener(new MouseAdapter(){
         public void mouseClicked(MouseEvent e){
            int year = Integer.parseInt(yearTF.getText());
            yearTF.setText(Integer.toString(year+1));         
         }
      });
      
      yearDown = new JButton();
      yearDown.setBounds(new Rectangle(220, 29, 15, 15));
      yearDown.setBackground(Color.black);
      yearDown.addMouseListener(new MouseAdapter(){
         public void mouseClicked(MouseEvent e){
            int year = Integer.parseInt(yearTF.getText());
            yearTF.setText(Integer.toString(year-1));         
         }
      });
      
      monthCb = new JComboBox();
      monthCb.setBounds(new Rectangle(250, 15, 100, 30));
      for(int i = 1; i <13; i++){
         monthCb.addItem(i);
      }
      monthCb.setSelectedIndex(calendar.getMonth());
      monthCb.addItemListener(new ItemListener(){
         public void itemStateChanged(java.awt.event.ItemEvent e) {
            int year = Integer.parseInt(yearTF.getText());
            int month = Integer.parseInt(monthCb.getSelectedItem().toString())-1;
            calendar.setYearMonth(year, month);
            model = new CalendarTableModel(getDate(year, month));
            outputTb.setModel(model);
            setWeekendColor();
         }
      });
      backBtn = new JButton(".........");
     backBtn.setBounds(new Rectangle(360,15,40,30));
     backBtn.setBackground(Color.orange);
     backBtn.setBorder(BorderFactory.createLineBorder(Color.orange, 1));
     backBtn.setForeground(Color.orange);
     backBtn.addMouseListener(new MouseAdapter(){
         public void mouseClicked(MouseEvent e){
           // fm.fileSave(filename, editer.getText());
            setVisible(false);
            new newmenu();
            
         }
      });
      

      inputPa = new JPanel();
      inputPa.setBounds(new Rectangle(0,15,500,50));
      inputPa.setBackground(Color.orange);
      inputPa.setLayout(null);
      inputPa.add(yearTF);
      inputPa.add(yearUp);
      inputPa.add(yearDown);
      inputPa.add(monthCb);
      inputPa.add(backBtn);
      
      outputPa = new JScrollPane();
      outputPa.setBounds(new Rectangle(0, 140, 500, 650));
      outputPa.setViewportView(getOutputTb());
            
      contentsPa = new JPanel();
      contentsPa = (JPanel)this.getContentPane();
      contentsPa.setLayout(null);
      contentsPa.add(inputPa);
      contentsPa.add(outputPa);
      
      this.setContentPane(contentsPa);
      this.setVisible(true);
      
   }
   
   
   
   
   private JTable getOutputTb(){
      if(outputTb == null){
         model = new CalendarTableModel(getDate(calendar.getYear(), calendar.getMonth()));
         outputTb = new JTable(model);
      }
      outputTb.setRowHeight(25);
      outputTb.addMouseListener(new MouseAdapter(){
         public void mouseClicked(MouseEvent e){
            String filename = yearTF.getText() + "_"+monthCb.getSelectedItem().toString()+
            "_"+outputTb.getValueAt(outputTb.getSelectedRow(), outputTb.getSelectedColumn()).toString();
            dialog = getDialog(filename);
         }
      });
      outputTb.setCellSelectionEnabled(false);
      setWeekendColor();
      return outputTb;
   }
   
   private Object[][] getDate(int year, int month){
      calendar.setYearMonth(year, month);
      String[] getdays = calendar.showCalendar();
      Object[][] days = new Object[calendar.getWeek()][7];
      int idx = 0;
      for(int i = 0; i <calendar.getWeek(); i++){
         for(int j = 0; j <7; j++){
            days[i][j] = getdays[idx];
            idx++;
         }
      }
      
      return days;      
   }
   
   private JDialog getDialog(final String filename){
      dialog = new JDialog(this);
      dialog.setSize(300, 250);
      dialog.setResizable(false);//������ ũ������ ���ϰ�
      dialog.setLocationRelativeTo(null);//�������� ȭ�� �����
      dialog.setModal(true);
      dialog.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
      
      editer = new JTextArea();
      editer.setEditable(true);
      if(fm.isSchedule(filename)){
         editer.setText("");
         editer.setText(fm.fileLoad(filename));
      }
      
      editerPa = new JScrollPane(editer);
      editerPa.setBounds(new Rectangle(5,5,275,160));
      
      dialogCon = new JPanel();
      dialogCon = (JPanel) dialog.getContentPane();
      dialogCon.setLayout(null);
      dialogCon.add(editerPa);
      
      okBt = new JButton("���");
      okBt.setFont(new Font("HY����B", Font.PLAIN, 15));
      okBt.setBounds(new Rectangle(40, 175, 100, 25));
      okBt.setBackground(Color.orange);
      okBt.addMouseListener(new MouseAdapter(){
         public void mouseClicked(MouseEvent e){
            fm.fileSave(filename, editer.getText());
            dialog.dispose();
         }
      });
      
      backBt = new JButton("�ڷΰ���");
      backBt.setFont(new Font("HY����B", Font.PLAIN, 15));
      backBt.setBounds(new Rectangle(150, 175, 100, 25));
      backBt.setBackground(Color.orange);
      backBt.addMouseListener(new MouseAdapter(){
         public void mouseClicked(MouseEvent e){
            fm.fileSave(filename, editer.getText());
            dialog.dispose();
            setVisible(false);
            new newmenu();
         }
      });

      dialogCon.add(okBt);
      dialogCon.add(backBt);
      dialog.setContentPane(dialogCon);
      dialog.setVisible(true);
      
      return dialog;
   }
   
   private void setWeekendColor(){
      if(sunday == null)
         sunday = new DefaultTableCellRenderer();
      column = outputTb.getColumnModel().getColumn(0);
      sunday.setForeground(Color.red);
      column.setCellRenderer(sunday);
      
      if(saturday == null)
         saturday = new DefaultTableCellRenderer();
      column = outputTb.getColumnModel().getColumn(6);
      saturday.setForeground(Color.blue);
      column.setCellRenderer(saturday);
      
   }

   public static void main(String[] args) {
      new Scheduler();
      
      
   }

}