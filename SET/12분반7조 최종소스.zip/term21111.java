import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class term21111 extends JFrame {

 static JTable Table;
 static JScrollPane Scroll;
 @SuppressWarnings("rawtypes")
 static Vector Headers = new Vector();
 static DefaultTableModel Model = null;
 @SuppressWarnings("rawtypes")
 static Vector Data = new 
  Vector();
 static JButton jbClick;
 static JFileChooser jChooser;
 static int tableWidth = 0; // ���̺� �ʺ���
 static int tableHeight = 0; // ���̺� ���̼���

 @SuppressWarnings("unchecked")
public term21111() {
  super("�ð�ǥ �ҷ�����");
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  JPanel ButtonPanel = new JPanel();
  ButtonPanel.setBackground(new Color(253, 225, 145));
  jChooser = new JFileChooser();
  jbClick = new JButton("�ҷ�����");
  JButton back = new JButton("�ڷΰ���");
  jbClick.setBackground(Color.white);
  back.setBackground(Color.white);
  jbClick.setFont(new Font("HY����B", Font.BOLD, 17));
  back.setFont(new Font("HY����B", Font.BOLD, 17));
  
  ButtonPanel.add(back, BorderLayout.CENTER);
  ButtonPanel.add(jbClick, BorderLayout.CENTER);
  
  back.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(ActionEvent arg0) {
         setVisible(false);
           new Start();
         
      }
  });

  
  jbClick.addActionListener(new ActionListener() {

   @Override
   public void actionPerformed(ActionEvent arg0) {
    jChooser.showOpenDialog(null);
    
    File file = jChooser.getSelectedFile();
    if(!file.getName().endsWith("xls")){
     JOptionPane.showMessageDialog(null, 
       "���������� �������ּ���",
       "����",JOptionPane.ERROR_MESSAGE);
    }
    else
    {
     fillData(file);
     Model = new DefaultTableModel(Data, Headers);
     tableWidth = Model.getColumnCount() * 95;
     tableHeight = Model.getRowCount()   * 25;
     Table.setPreferredSize(new Dimension(tableWidth, tableHeight));
 
     Table.setModel(Model);
    }
   }
  });

  Table = new JTable();
  Table.setAutoCreateRowSorter(true);
  Model = new DefaultTableModel(Data, Headers);

  Table.setModel(Model);
  Table.setBackground(Color.WHITE);

  Table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
  Table.setEnabled(false);
  Table.setRowHeight(25);
  Table.setRowMargin(4);

  tableWidth = Model.getColumnCount() * 100;
  tableHeight = Model.getRowCount() * 20;
  Table.setPreferredSize(new Dimension(
    tableWidth, tableHeight));

  Scroll = new JScrollPane(Table);
  Scroll.setBackground(Color.WHITE);
  Scroll.setPreferredSize(new Dimension(600, 300));
  Scroll.setHorizontalScrollBarPolicy(
    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
  Scroll.setVerticalScrollBarPolicy(
    JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
  getContentPane().add(ButtonPanel, BorderLayout.NORTH);
  getContentPane().add(Scroll, BorderLayout.CENTER);
  setSize(600, 600);
  setResizable(true);
  setVisible(true);
 }

 @SuppressWarnings("unchecked")
void fillData(File file) {

  Workbook workbook = null;
  try {
   try {
    workbook = Workbook.getWorkbook(file);
   } catch (IOException ex) {
    Logger.getLogger(
      term21111.class.
      getName()).log(Level.SEVERE, null, ex);
   }
   Sheet sheet = workbook.getSheet(0);
   
   Headers.clear();
   for (int i = 0; i < sheet.getColumns(); i++) {
    Cell cell1 = sheet.getCell(i, 0);
    Headers.add(cell1.getContents());
   }

   Data.clear();
   for (int j = 1; j < sheet.getRows(); j++) {
    Vector d = new Vector();
    for (int i = 0; i < sheet.getColumns(); i++) {

     Cell cell = sheet.getCell(i, j);
     
     d.add(cell.getContents());

    }
    d.add("\n");
    Data.add(d);
   }
  } catch (BiffException e) {
   e.printStackTrace();
  }
 }

 public static void main(String[] args) {

  new term21111();
 }
}