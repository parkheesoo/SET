import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
 
public class LectureDefaultJTableDAO {

    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
 
    public LectureDefaultJTableDAO() {
        try {
            // �ε�
            Class.forName("org.postgresql.Driver");
            // ����
            con = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/postgres",
                            "planer", "2580");
        } catch (ClassNotFoundException e) {
            System.out.println(e + "=> �ε� fail");
        } catch (SQLException e) {
            System.out.println(e + "=> ���� fail");
        }
    }
    
    //DB�ݱ� ��� �޼ҵ�
    public void dbClose() {
        try {
            if (rs != null) rs.close();
            if (st != null) st.close();
            if (ps != null) ps.close();
        } catch (Exception e) {
            System.out.println(e + "=> dbClose fail");
        }
    }
 
    //lecturelist�� ��� ���ڵ� ��ȸ
    public void LectureSelectAll(DefaultTableModel t_model) {
        try {
            st = con.createStatement();
            rs = st.executeQuery("select * from plan order by name");
 
            // DefaultTableModel�� �ִ� ���� ������ �����
            for (int i = 0; i < t_model.getRowCount();) {
                t_model.removeRow(0);
            }
 
            while (rs.next()) {
                Object data[] = { rs.getString(1), rs.getString(2),
                        rs.getString(3), rs.getString(4), rs.getString(5), 
                       rs.getString(6), rs.getString(7)
                        };
 
                t_model.addRow(data); //DefaultTableModel�� ���ڵ� �߰�
            }
        } catch (SQLException e) {
            System.out.println(e + "=> LectureSelectAll fail");
        } finally {
            dbClose();
        }
    }
 
    //�˻��ܾ �ش��ϴ� ���ڵ� �˻��ϱ� (like�����ڸ� ����Ͽ� _, %�� ����Ҷ��� PreparedStatemnet�ȵȴ�. �ݵ�� Statement��ü�� �̿���)
    public void getLectureSearch(DefaultTableModel dt, String fieldName, String word) {
        String sql = "SELECT * FROM plan WHERE " + fieldName.trim()
                + " LIKE '%" + word.trim() + "%'";
 
        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);
 
            // DefaultTableModel�� �ִ� ���� ������ �����
            for (int i = 0; i < dt.getRowCount();) {
                dt.removeRow(0);
            }
 
            while (rs.next()) {
                Object data[] = { rs.getString(1), rs.getString(2),
                        rs.getString(3), rs.getString(4), rs.getString(5),
                       rs.getString(6), rs.getString(7)
                        };
 
                dt.addRow(data);
            }
 
        } catch (SQLException e) {
            System.out.println(e + "=> getLectureSearch fail");
        } finally {
            dbClose();
        }
    }
}