import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.imageio.ImageIO;

 
@SuppressWarnings({ "unused", "serial" })
public class Start extends JFrame {
   
   Image img = null;
   JButton btn1 = new JButton("���ǰ�ȹ����ȸ"); 
   JButton btn2 = new JButton("�ð�ǥ ���"); 
   JButton btn3 = new JButton("��������");
   JButton btn4 = new JButton("�ڷΰ���");
   
   Start(){
      setTitle("�α�����ȭ��");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      Picture();
      
      btn1.addActionListener(new MyActionListener());
      btn2.addActionListener(new MyActionListener());
      btn3.addActionListener(new MyActionListener());
      btn4.addActionListener(new MyActionListener());
      
      btn1.setFont(new Font("HY����B", Font.BOLD, 15));
      btn2.setFont(new Font("HY����B", Font.BOLD, 15));
      btn3.setFont(new Font("HY����B", Font.BOLD, 15));
      btn4.setFont(new Font("HY����B", Font.BOLD, 15)); 
      
      btn1.setPreferredSize(new Dimension(146, 35));
       btn2.setPreferredSize(new Dimension(146, 35));
       btn3.setPreferredSize(new Dimension(146, 35));
       btn4.setPreferredSize(new Dimension(146, 35));
       
       btn1.setBorder(BorderFactory.createLineBorder(Color.orange, 3));
       btn2.setBorder(BorderFactory.createLineBorder(Color.orange, 3));
       btn3.setBorder(BorderFactory.createLineBorder(Color.orange, 3));
       btn4.setBorder(BorderFactory.createLineBorder(new Color(253, 225, 145), 3));
       
       btn1.setBackground(Color.white);
       btn2.setBackground(Color.white);
       btn3.setBackground(Color.white);
       btn4.setBackground(Color.white);
      
      First();
      second();
      
      setSize(500,650);
      setLocationRelativeTo(null);
      setVisible(true);   
   }
   
   public void First (){
      JPanel p1 = new JPanel();
      JPanel p2 = new JPanel();  
      JPanel p3 = new JPanel();  
      JPanel p4 = new JPanel();

      p1.setBackground(Color.orange);
      p2.setBackground(Color.orange);
      p3.setBackground(Color.orange);
      p4.setBackground(new Color(253, 225, 145));
      
      p1.add(btn1);
      p2.add(btn2);
      p3.add(btn3);
      p4.add(btn4);
      
      add(p1);
      add(p2);
      add(p3);
      add(p4);
      
      p1.setBounds(30, 460, 150, 50);
      p2.setBounds(170, 460, 160, 50);
      p3.setBounds(310, 460, 150, 50);
      p4.setBounds(170, 530, 170, 50);
   }
   
   public void second() {
      JPanel p = new JPanel();
       p.setLayout(null);
       p.setBackground(new Color(253, 225, 145));
       
     // Label l1= new Label("�����");
     //  l1.setFont(new Font("�޸ո���T", Font.BOLD,17));
     // add(l1);
     // l1.setBounds(5, 0, 60, 40);
      
      JLabel t2 = new JLabel();
      t2.setFont(new Font("HY����B", Font.BOLD, 25));
      add(t2);//�������� ��ġ ����
      t2.setBounds(60, 30, 200, 30);
      //t2.setBackground(Color.white);
      //t2.setEditable(false);//���� �Ұ��� �ϰ� ������ִ� ��
      
      //JFileChooser fs = new JFileChooser(new File("ȸ������.txt"));
      //fs.setFileFilter(new FileTypeFilter(".dat","Data File"));
      //int result = fs.showOpenDialog(null);
      //if(result == JFileChooser.APPROVE_OPTION) {
      
      try { //�α����ϰ� ȸ������ ������ �Է�
         String s; 
           String[] array; 
           //File fi = fs.getSelectedFile();
           BufferedReader br = new BufferedReader(new FileReader("ȸ������.txt")); 
           
           while ((s = br.readLine()) != null) {
              
              array = s.split("/");
              t2.setText(array[0] + " ȸ����"); //�̸�   
           }
           br.close();   
      } catch (IOException e2) {
         e2.printStackTrace();   
      } 
     // }
      add(p);
   }
   
   public void Picture() {
      
      ImageIcon time = new ImageIcon("images/time.png");
       JLabel timetable = new JLabel(time); 
       add(timetable);
      timetable.setBounds(40, 140, 400, 300);
      //timetable.setBackground(new Color(253, 225, 145));
      //timetable.setBorder(BorderFactory.createLineBorder(new Color(253, 225, 145), 5));
      /*timetable.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            setVisible(false);
            new term21111();   
         }   
      });*/
   }

 class MyActionListener implements ActionListener{
    public void actionPerformed(ActionEvent e) {
       setVisible(false);
       Object b = e.getSource();
         
       if(b == btn1) {
          new MenuJTabaleExam();
         }
         else if(b == btn2) {
            new term211();
         }
         else if(b == btn3) {
            new HakjumCalculator();
         }
         else if(b == btn4) {
            new newmain();
         }    
    }    
 }
 
 public static void main(String[] args) {
      // TODO Auto-generated method stub
    new Start();    
 } 
}