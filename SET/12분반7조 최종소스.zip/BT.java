import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("unused")
public class BT extends JFrame {

   private JRadioButton[] radio = new JRadioButton[4];
   private String[] text = { "���ϱ�����", "�߰��ϱ�����", "��ȯ����",""};
   private ImageIcon[] image = { new ImageIcon("images/bus.png")};
   private JLabel imageLabel = new JLabel();
   
   public BT() {
	   
      setTitle("��Ʋ���� �ȳ�");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Container c = getContentPane();
      c.setLayout(new BorderLayout());

      JPanel radioPanel = new JPanel();
      radioPanel.setBackground(Color.pink);

      ButtonGroup g = new ButtonGroup();
      for (int i = 0; i < radio.length; i++) {
         radio[i] = new JRadioButton(text[i]);
         g.add(radio[i]);
         radioPanel.add(radio[i]);
         radio[i].addItemListener(new MyItemListener());
      }
      
      radio[3].setSelected(true);
      c.add(radioPanel, BorderLayout.NORTH);
      c.add(imageLabel, BorderLayout.CENTER);
      imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
      imageLabel.setBackground(Color.YELLOW);
      setSize(500,650);
      setLocationRelativeTo(null);
      setVisible(true);
      
      JButton btn1 = new JButton("�ڷΰ���");
      btn1.addActionListener(new MyActionListener());
      c.add(btn1, BorderLayout.SOUTH);
   }

   public void Picture() {
       
 	  JLabel label = new JLabel(new ImageIcon("images/bus.png"));
 	  JButton btn1 = new JButton("�ڷΰ���");
      btn1.addActionListener(new MyActionListener());
     
       add(label);   
       label.setBounds(40, 140, 400, 300);
       add(btn1, BorderLayout.SOUTH);
    }
 
   class MyItemListener implements ItemListener {
      public void itemStateChanged(ItemEvent e) {
    	 setVisible(false);

      if (radio[0].isSelected()) {
            new TabbedPaneEx1();
         }       
       else if (radio[1].isSelected()) {
           new TabbedPaneEx2();
        }  
       else if (radio[2].isSelected()) {
           new TabbedPaneEx3(); 
        }   
       else{
           imageLabel.setIcon(image[0]);
        }   
      }
   }
   
   class MyActionListener implements ActionListener {
	   public void actionPerformed(ActionEvent e) {
		   setVisible(false);
		   JButton b = (JButton)e.getSource();
		   new newmenu();
	   }
   }
   
    
   public static void main(String[] args) {
      // TODO Auto-generated method stub
	   new BT();
	   

   }
}